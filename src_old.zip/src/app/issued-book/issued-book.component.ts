import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-issued-book',
  templateUrl: './issued-book.component.html',
  styleUrls: ['./issued-book.component.css']
})
export class IssuedBookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
