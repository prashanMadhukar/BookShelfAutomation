import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  
  constructor() { }
}

export class Book{
  constructor(
    public bookId:number=null,
    public bookTitle:string=null,
    public bookAuthor:string=null,
    public bookPublisher:string=null,
    public bookPrice:ConstrainDouble=null,
    public bookQuantity:number=null
  ) {}
}


@Injectable({
  providedIn: 'root'
})

export class HttpClientService {

  constructor(private httpClient:HttpClient) { }

  getBooks(){    
    return this.httpClient.get<Book[]>('http://192.168.105.212:8080/books');
  }

  addBooks(bookObj:Book ){    
    return this.httpClient.post('http://192.168.105.212:8080/books',bookObj);
  }

  getBooksById(bookId : number){
    return this.httpClient.get<Book>('http://192.168.105.212:8080/books/'+bookId);
  }

  searchBooks(bookObj: Book){
    return this.httpClient.post('http://192.168.105.212:8080/books/search/', bookObj);
  }

  removeBook(bookId : number){
    return this.httpClient.delete('http://192.168.105.212:8080/books/'+bookId);
  }
}