import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdminServicesService {

 
  constructor(private httpClient:HttpClient) { }
  authenticateAdmin(email: string, password:string){
    var user = new Admin();
    user.adminEmail=email;
    user.adminPassword=password;
    console.log(email+"  "+password);
    return this.httpClient.post<Admin>('http://192.168.105.212:8080/adminlogin',user);
  }
  
}
export class Admin{
  constructor(
    public   adminId:number=null,
    public   adminName:string=null,
    public   adminPassword:string=null,
    public   adminDob:string=null,
    public   adminAddress:string=null,
    public   adminEmail:string=null
  ) {}
}
