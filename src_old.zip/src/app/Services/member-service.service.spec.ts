import { TestBed } from '@angular/core/testing';

import { MemberServicesService } from './member-service.service';

describe('MemberServicesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MemberServicesService = TestBed.get(MemberServicesService);
    expect(service).toBeTruthy();
  });
});
