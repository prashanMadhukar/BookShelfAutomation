import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MemberServicesService {

  constructor() { }
}

export class Member{
  constructor(
    public   memberId:number=null,
    public   memberPassword:string=null,
    public   memberDob:Date=null,
    public   memberAddress:string=null,
    public   memberEmail:string=null,
    public   isSuspended:boolean=false
  ) {}
}

@Injectable({
  providedIn: 'root'
})

export class HttpClientService {

  constructor(private httpClient:HttpClient) { }

  getMembers(){    
    return this.httpClient.get<Member[]>('http://192.168.105.212:8080/members');
  }

  addMembers(memberObj:Member ){    
    return this.httpClient.post('http://192.168.105.212:8080/members',memberObj);
  }

  getMemberByEmail(memberEmail : string){
    return this.httpClient.get<Member>('http://192.168.105.212:8080/members/email/'+memberEmail);
  }
  
  getMemberById(memberId : number){
    return this.httpClient.get<Member>('http://192.168.105.212:8080/members/'+memberId);
  }

  removeMember(memberId : number){
    return this.httpClient.delete('http://192.168.105.212:8080/members/'+memberId);
  }
  
  authenticateMember(email: string, password:string){
    var user = new Member();
    user.memberEmail=email;
    user.memberPassword=password;
    console.log(email+"  "+password);
    return this.httpClient.post<Member>('http://192.168.105.212:8080/memberlogin',user);
  }
}