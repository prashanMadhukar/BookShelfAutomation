import { Component, OnInit } from '@angular/core';
import { HttpClientService } from '../Services/service.service';

@Component({
  selector: 'app-view-all-book',
  templateUrl: './view-all-book.component.html',
  styleUrls: ['./view-all-book.component.css']
})

export class ViewAllBookComponent implements OnInit {

  books: any[];

  constructor(private svc: HttpClientService) { 
    this.svc.getBooks().subscribe(
      response => this.books=response
    );
  }

  ngOnInit() {
  }
  
}
