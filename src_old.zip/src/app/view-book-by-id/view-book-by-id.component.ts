import { Component, OnInit } from '@angular/core';
import { HttpClientService } from '../Services/service.service';

@Component({
  selector: 'app-view-book-by-id',
  templateUrl: './view-book-by-id.component.html',
  styleUrls: ['./view-book-by-id.component.css']
})
export class ViewBookByIdComponent implements OnInit {

  private isSearch: boolean = false;
  books: any;
  constructor(private svc: HttpClientService) { }

  ngOnInit() {
  }

  showBookById(id:number){
    this.isSearch = !this.isSearch;
    this.svc.getBooksById(id).subscribe(
      response => this.books=response
    );
  }
}
