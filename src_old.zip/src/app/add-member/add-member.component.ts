import { Component, OnInit } from '@angular/core';
import { Member, HttpClientService } from '../Services/member-service.service';

@Component({
  selector: 'app-add-member',
  templateUrl: './add-member.component.html',
  styleUrls: ['./add-member.component.css']
})
export class AddMemberComponent implements OnInit {

  memberObj = new Member();
  

  constructor(private httpclient:HttpClientService) {
   }

  ngOnInit() {
  }

  sendData(){
    return this.httpclient.addMembers(this.memberObj).subscribe(
      response =>{ 
      console.log("successful");
      this.memberObj.memberId=null;
      this.memberObj.memberPassword=null;
      this.memberObj.memberDob=null;
      this.memberObj.memberAddress=null;
      this.memberObj.memberEmail=null;
      this.memberObj.isSuspended=null;

      }
      );
      
  }

  setProperty1(){
    this.memberObj.isSuspended = true;
  }
  setProperty2(){
    this.memberObj.isSuspended = false;
  }

}
