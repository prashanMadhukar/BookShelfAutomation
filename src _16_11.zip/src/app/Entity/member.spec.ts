import { Member } from './member';

describe('Member', () => {
  it('should create an instance', () => {
    expect(new Member()).toBeTruthy();
  });
});
