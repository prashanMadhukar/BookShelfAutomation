import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Member } from '../Entity/member';

@Injectable({
  providedIn: 'root'
})
export class MemberService {

  constructor(private httpClient:HttpClient) { }

  authenticateMember(email: string, password:string){
    var user = new Member();
    user.memberEmail=email;
    user.memberPassword=password;
    console.log(email+"  "+password);
    return this.httpClient.post<Member>('http://localhost:8080/memberlogin',user);
  }

  getMembers(){    
    return this.httpClient.get<Member[]>('http://localhost:8080/members');
  }

  addMembers(memberObj:Member ){    
    return this.httpClient.post('http://localhost:8080/members',memberObj);
  }

  getMemberByEmail(memberEmail : string){
    return this.httpClient.get<Member>('http://localhost:8080/members/email/'+memberEmail);
  }
  
  getMemberById(memberId : number){
    return this.httpClient.get<Member>('http://localhost:8080/members/'+memberId);
  }

  removeMember(memberId : number){
    return this.httpClient.delete('http://localhost:8080/members/'+memberId);
  }
  
}