import { Component, OnInit } from '@angular/core';
import { MemberService } from '../Services/member.service';

@Component({
  selector: 'app-view-member-by-id',
  templateUrl: './view-member-by-id.component.html',
  styleUrls: ['./view-member-by-id.component.css']
})
export class ViewMemberByIdComponent implements OnInit {

  private isSearch : boolean = false;
  member: any;

  constructor(private svc: MemberService) { }

  ngOnInit() {
  }

  showMemberById(id:number){
    this.isSearch = true;
    this.svc.getMemberById(id).subscribe(
      response => this.member = response
    );
  }
  
}
