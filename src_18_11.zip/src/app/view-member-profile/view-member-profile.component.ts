import { Component, OnInit } from '@angular/core';
import { Member } from '../Entity/member';
import { MemberService } from '../Services/member.service';

@Component({
  selector: 'app-view-member-profile',
  templateUrl: './view-member-profile.component.html',
  styleUrls: ['./view-member-profile.component.css']
})
export class ViewMemberProfileComponent implements OnInit {

  member = new Member();
  constructor(private http: MemberService ) { }

  ngOnInit() {
    var userEmail =  sessionStorage.getItem('email');
    this.http.getMemberByEmail(userEmail).subscribe(
      response => this.member = response
    );
    console.log(this.member);
  }

  
}
