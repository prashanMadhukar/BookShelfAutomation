import { SubBook } from './sub-book';

describe('SubBook', () => {
  it('should create an instance', () => {
    expect(new SubBook()).toBeTruthy();
  });
});
